#include "music_app.hpp"
#include <iostream>
#include <fstream>
#include <sstream>
#include <algorithm>

std::map<std::string, Song> songs;
std::map<std::string, Album> albums;
std::map<std::string, Artist> artists;
std::map<std::string, Playlist> playlists;

std::string Artist::getId() const { return id; }
std::string Album::getId() const { return id; }
std::string Song::getId() const { return id; }
std::string Playlist::getId() const { return id; }

void loadArtists(const std::string& filename) {
    std::ifstream file(filename);
    std::string line;
    while (std::getline(file, line)) {
        std::istringstream ss(line);
        Artist artist;
        std::getline(ss, artist.id, ',');
        std::getline(ss, artist.name, ',');
        std::getline(ss, artist.genre);
        artists[artist.id] = artist;
    }
}

void loadAlbums(const std::string& filename) {
    std::ifstream file(filename);
    std::string line;
    while (std::getline(file, line)) {
        std::istringstream ss(line);
        Album album;
        std::string year;
        std::getline(ss, album.id, ',');
        std::getline(ss, album.title, ',');
        std::getline(ss, year);
        album.releaseYear = std::stoi(year);
        albums[album.id] = album;
    }
}

void loadSongs(const std::string& filename) {
    std::ifstream file(filename);
    std::string line;
    while (std::getline(file, line)) {
        std::istringstream ss(line);
        Song song;
        std::string duration;
        std::getline(ss, song.id, ',');
        std::getline(ss, song.title, ',');
        std::getline(ss, duration, ',');
        std::getline(ss, song.albumId, ',');
        std::string artistId;
        while (std::getline(ss, artistId, ';')) {
            song.artistIds.push_back(artistId);
            artists[artistId].songIds.insert(song.id);
        }
        song.duration = std::stoi(duration);
        songs[song.id] = song;
        albums[song.albumId].songIds.push_back(song.id);
    }
}

void displayAllArtists() {
    for (const auto& [id, artist] : artists)
        std::cout << artist.name << " (" << artist.genre << ")\n";
}

void displayAllAlbums() {
    for (const auto& [id, album] : albums)
        std::cout << album.title << " (" << album.releaseYear << ")\n";
}

void displayAllSongs() {
    for (const auto& [id, song] : songs)
        std::cout << song.title << " (" << song.duration << "s)\n";
}

void createPlaylist() {
    Playlist p;
    std::cout << "Enter playlist ID: "; std::cin >> p.id;
    std::cout << "Enter playlist name: "; std::cin.ignore(); std::getline(std::cin, p.name);
    playlists[p.id] = p;
    std::cout << "Playlist created.\n";
}

void updatePlaylist() {
    std::string id;
    std::cout << "Enter playlist ID to update: "; std::cin >> id;
    if (playlists.count(id)) {
        std::cout << "Enter new name: "; std::cin.ignore(); std::getline(std::cin, playlists[id].name);
        std::cout << "Playlist updated.\n";
    } else std::cout << "Playlist not found.\n";
}

void deletePlaylist() {
    std::string id;
    std::cout << "Enter playlist ID to delete: "; std::cin >> id;
    if (playlists.erase(id)) std::cout << "Playlist deleted.\n";
    else std::cout << "Playlist not found.\n";
}

void listPlaylists() {
    for (const auto& [id, p] : playlists)
        std::cout << "Playlist: " << p.name << " [" << id << "]\n";
}

void playlistMenu() {
    int choice;
    do {
        std::cout << "\n-- Playlist Menu --\n";
        std::cout << "1. Create Playlist\n2. Update Playlist\n3. Delete Playlist\n4. List Playlists\n0. Back\n";
        std::cin >> choice;
        switch (choice) {
            case 1: createPlaylist(); break;
            case 2: updatePlaylist(); break;
            case 3: deletePlaylist(); break;
            case 4: listPlaylists(); break;
        }
    } while (choice != 0);
}
